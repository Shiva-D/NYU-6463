	
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

void parseI(istream& is, ostream& os, const string& op);

void parseJ(istream& is, ostream& os, const string& op);

void parseR(istream& is, ostream& os, const string& op, const string& func);

string toBinary(int n);
string toBinary(string hex);

void addBinFromHex(vector<char>& v, char c);

int main (int argc, char *argv[]) {
	if (argc != 3) {
		cerr << "This function requires exactly two arguments: " << endl;
		cerr << "\t-the file input name" << endl;
		cerr << "\t-the file output name" << endl << endl;
		cerr << "Command format: " << endl << "--------------------" << endl;
		cerr << argv[0] << " <input-file-name> <output-file-name>" << endl;
		return 1;
	}
	ifstream input(argv[1]);	

	if (!input) {
		cerr << "That file does not exist!" << endl;
		return 1;
	}

	ofstream output(argv[2]);
	
	string command, hex;
	int param, line = 1;

	while (input >> command) {
		cout << line << " Line Compiled" << endl;
		if (command == "ADD") { parseR(input, output, "000000", "010000"); }
		else if (command == "ADDI") { parseI(input, output, "000001"); }
		else if (command == "SUB") { parseR(input, output, "000000", "010001"); }
		else if (command == "SUBI") { parseI(input, output, "000010"); }
		else if (command == "AND") { parseR(input, output, "000000", "010010"); }
		else if (command == "ANDI") { parseI(input, output, "000011"); }
		else if (command == "OR") { parseR(input, output, "000000", "010011"); }
		else if (command == "NOR") { parseR(input, output, "000000", "010100"); }
		else if (command == "ORI") { parseI(input, output, "000100"); }
		else if (command == "SHL") { parseI(input, output, "000101"); }
		else if (command == "SHR") { parseI(input, output, "000110"); }
		else if (command == "LW") { parseI(input, output, "000111"); }
		else if (command == "SW") { parseI(input, output, "001000"); }
		else if (command == "BLT") { parseI(input, output, "001001"); }
		else if (command == "BEQ") { parseI(input, output, "001010"); }
		else if (command == "BNE") { parseI(input, output, "001011"); }
		else if (command == "JMP") { parseJ(input, output, "001100"); }
		else if (command == "HAL") {
			string b = toBinary("0x3F");
			int j = 2;
			vector<char> clist;
			for (char c : b) {
				if (j > 0) {
					--j;
					continue;
				}
				clist.push_back(c);
			}
			string o(clist.begin(), clist.end());
			output << o << "00" << "\n";
			output << "00000000" << "\n";
			output << "00000000" << "\n";
			output << "00000000" << "\n";
		}
		else {
			cerr << "Command '" << command << "' unknown on line " << line << endl;
			return 1;  
		}
		++line;
		input.clear();
	}
	cout << "Compilation Successful!" << endl;
}

void parseR(istream& input, ostream& output, const string& op, const string& func) {
	int param;
	string fullinst;
	fullinst = op ;
	while (input >> param) { fullinst += toBinary(param); }
	fullinst += "00000" + func;
	output << fullinst.substr (0,8)  << "\n";
	output << fullinst.substr (8,8)  << "\n";
	output << fullinst.substr (16,8) << "\n";
	output << fullinst.substr (24,8) << "\n";
}

void parseI(istream& input, ostream& output, const string& op) {
	int param;
	string hex;
	string fullinst;
	fullinst = op ;
	input >> param;
	fullinst += toBinary(param);
	input >> param;
	fullinst += toBinary(param);
	input >> hex;
	fullinst += toBinary(hex);
	output << fullinst.substr (0,8)  << "\n";
	output << fullinst.substr (8,8)  << "\n";
	output << fullinst.substr (16,8) << "\n";
	output << fullinst.substr (24,8) << "\n";
}

void parseJ(istream& input, ostream& output, const string& op) {
	string hex;
	string fullinst;
	fullinst = op;
	input >> hex;
	string s = toBinary(hex);
	int j = 2;
	vector<char> clist;
	for (char c : s) {
		if (j > 0) {
			--j;
			continue;
		}
		clist.push_back(c);
	}
	string o(clist.begin(), clist.end());
	fullinst += o;
	output << fullinst.substr (0,8)  << "\n";
	output << fullinst.substr (8,8)  << "\n";
	output << fullinst.substr (16,8) << "\n";
	output << fullinst.substr (24,8) << "\n";

}

string toBinary(int n) {
	vector<char> bin;
	for (int i = 0; i < 5; ++i) {
		bin.push_back(n % 2 ? '1' : '0');
		n /= 2;
	}
	reverse(bin.begin(), bin.end());
	string str(bin.begin(), bin.end());
	return str;
}

string toBinary(string hex) {
	vector<char> bin;
	bool d = true;
	for (char& c : hex) {
		if (d || c == 'x' || c == 'X') {
			d = false;
			continue;
		}
		addBinFromHex(bin, c);	
	}
	string str(bin.begin(), bin.end());
	return str;	
}



void addBinFromHex(vector<char>& v, char c) {
	if(c >= 'a' && c <= 'z') {
    	c -= 32;
	}
	if (c != 'A' && c != 'B' && c != 'C' && c != 'D' && c != 'E' && c != 'F') {
		string s = toBinary((int)(c - '0'));
		bool d = true;
		for (char& c : s) {
			if (d) {
				d = false;
				continue;
			}
			v.push_back(c);	
		}
	}
	else {
		if (c == 'A') {
			v.push_back('1');
			v.push_back('0');
			v.push_back('1');
			v.push_back('0');
		}
		else if (c == 'B') {
			v.push_back('1');
			v.push_back('0');
			v.push_back('1');
			v.push_back('1');
		}
		else if (c == 'C') {
			v.push_back('1');
			v.push_back('1');
			v.push_back('0');
			v.push_back('0');
		}
		else if (c == 'D') {
			v.push_back('1');
			v.push_back('1');
			v.push_back('0');
			v.push_back('1');
		}
		else if (c == 'E') {
			v.push_back('1');
			v.push_back('1');
			v.push_back('1');
			v.push_back('0');
		}
		else if (c == 'F') {
			v.push_back('1');
			v.push_back('1');
			v.push_back('1');
			v.push_back('1');
		}

	}
}