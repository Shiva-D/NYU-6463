#include<iostream>
#include<string>
#include<vector>
#include<bitset>
#include<fstream>
#include <stdint.h>   // for uint32_t
#include <limits.h>   // for CHAR_BIT
using namespace std; 

static inline uint32_t rotl32 (uint32_t n, unsigned int c)
{
  const unsigned int mask = (CHAR_BIT*sizeof(n) - 1);  // assumes width is a power of 2.

  // assert ( (c<=mask) &&"rotate by type width or more");
  c &= mask;
  return (n<<c) | (n>>( (-c)&mask ));
}

int main()
{
    int s[26] = {};
    int l[4] = {0,0,0,0};
    s[0] = 0xB7E15163;
    cout << hex << s[0] << endl;
    for(int i = 1; i<26 ; i++){
        s[i] = s[i-1] + 0x9E3779B9;
        
        cout << hex << s[i] << endl;
    }
    cout << "\n";
    int a = 0;
    int b = 0;
    int x = 0;
    int y = 0;
    for (int i = 0; i != 78 ; i++){
        a = rotl32((s[x]+ a + b),3);
        b = rotl32((l[y]+a+b),(a+b));
        s[x] = a;
        l[y] = b;
        if (x != 25){
            x++;
        }
        else{
            x = 0;
        }
        if(y != 3){
            y++;  
        }
        else{
            y = 0;
        }
    }
     for(int i = 0; i<4 ; i++){
        
        cout << hex << l[i] << endl;
    }
        cout << "\n";

     for(int i = 0; i<26 ; i++){
        
        cout << hex << s[i] << endl;
    }
    cout << "done"; 
    return 0;
}



